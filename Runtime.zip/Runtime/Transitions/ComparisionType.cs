namespace StateMachinePackage.Runtime.Transitions
{
    public enum ComparisonType
    {
        Equal,
        LessThan,
        GreaterThan,
        LessThanOrEqual,
        GreaterThanOrEqual
    }
}